@extends('layouts.app')

@section('content')
<h1>Historial de Modificaciones</h1>
{{-- Aquí va la lógica para mostrar los cambios --}}
@endsection