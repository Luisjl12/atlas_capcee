@extends('layouts.app')

@section('content')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="container mt-4">
    <h2 class="mb-4 text-dark"><i class="fas fa-chart-line"></i> Reportes Financieros Infraescolares</h2>

    @if($reportes->isEmpty())
        <div class="alert alert-info text-center shadow-sm">
            <i class="fas fa-info-circle fa-2x mb-2"></i>
            <h5>Aún no hay reportes publicados.</h5>
            <p class="mb-0">Cuando el Administrador suba un nuevo reporte, aparecerá aquí.</p>
        </div>
    @else
        <div class="row">
            @foreach($reportes as $reporte)
                @php 
                    $grafica = json_decode($reporte->datos_grafica); 
                @endphp

                <div class="col-md-12 mb-5">
                    <div class="card shadow-sm h-100">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><strong>{{ $reporte->titulo }}</strong></h5>
                            <a href="{{ asset('storage/' . $reporte->archivo_pdf) }}" target="_blank" class="btn btn-danger btn-sm">
                                <i class="fas fa-file-pdf"></i> Descargar PDF
                            </a>
                        </div>
                        <div class="card-body">
                            
                            <ul class="nav nav-tabs" id="tabs_{{ $reporte->id }}" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#barras_{{ $reporte->id }}" type="button" role="tab">
                                        <i class="fas fa-chart-bar"></i> Comparativa (Barras)
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#pastel_{{ $reporte->id }}" type="button" role="tab">
                                        <i class="fas fa-chart-pie"></i> Gastos Pagados (Pastel)
                                    </button>
                                </li>
                                <li class="nav-item" role="presentation">
                                    <button class="nav-link" data-bs-toggle="tab" data-bs-target="#tabla_{{ $reporte->id }}" type="button" role="tab">
                                        <i class="fas fa-table"></i> Tabla Detallada
                                    </button>
                                </li>
                            </ul>

                            <div class="tab-content pt-4" id="contenidoTabs_{{ $reporte->id }}">
                                
                                <div class="tab-pane fade show active" id="barras_{{ $reporte->id }}" role="tabpanel">
                                    <div style="height: 350px; background-color: #ffffff !important; border-radius: 8px; padding: 10px; border: 1px solid #dee2e6;">
                                        <canvas id="grafica_barras_{{ $reporte->id }}" style="background-color: transparent !important;"></canvas>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="pastel_{{ $reporte->id }}" role="tabpanel">
                                    <div style="height: 350px; display: flex; justify-content: center; background-color: #ffffff !important; border-radius: 8px; padding: 10px; border: 1px solid #dee2e6;">
                                        <canvas id="grafica_pastel_{{ $reporte->id }}" style="background-color: transparent !important;"></canvas>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="tabla_{{ $reporte->id }}" role="tabpanel">
                                    <div class="table-responsive">
                                        <table class="table table-bordered table-striped table-hover text-center align-middle">
                                            <thead style="background-color: #691C32; color: white;">
                                                <tr>
                                                    <th>Objeto del Gasto</th>
                                                    <th>Aprobado</th>
                                                    <th>Presupuesto Vigente</th>
                                                    <th>Pagado</th>
                                                    <th>Saldo (Diferencia)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @if(isset($grafica->labels))
                                                    @foreach($grafica->labels as $index => $label)
                                                    <tr>
                                                        <td class="text-start fw-bold">{{ $label }}</td>
                                                        <td>${{ number_format((float)($grafica->aprobado[$index] ?? 0), 2) }}</td>
                                                        <td>${{ number_format((float)($grafica->vigente[$index] ?? 0), 2) }}</td>
                                                        <td class="text-success fw-bold">${{ number_format((float)($grafica->pagado[$index] ?? 0), 2) }}</td>
                                                        <td class="text-primary fw-bold">${{ number_format((float)($grafica->diferencia[$index] ?? 0), 2) }}</td>
                                                    </tr>
                                                    @endforeach
                                                @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div> </div>
                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', function() {
                        const paletaColores = [
                            'rgba(13, 110, 253, 0.8)', // Azul
                            'rgba(25, 135, 84, 0.8)',  // Verde
                            'rgba(255, 193, 7, 0.8)',  // Amarillo
                            'rgba(108, 117, 125, 0.8)',// Gris
                            'rgba(220, 53, 69, 0.8)',  // Rojo
                            'rgba(23, 162, 184, 0.8)', // Cyan
                            'rgba(255, 152, 0, 0.8)',  // Naranja
                            'rgba(111, 66, 193, 0.8)', // Morado
                            'rgba(32, 201, 151, 0.8)', // Teal
                            'rgba(159, 34, 65, 0.8)'   // Guinda
                        ];

                        // 1. INICIALIZAR GRÁFICA DE BARRAS
                        const ctxBarras = document.getElementById('grafica_barras_{{ $reporte->id }}');
                        if (ctxBarras) {
                            new Chart(ctxBarras.getContext('2d'), {
                                type: 'bar', 
                                data: {
                                    labels: {!! json_encode($grafica->labels ?? []) !!}, 
                                    datasets: [
                                        { label: 'Aprobado', data: {!! json_encode($grafica->aprobado ?? []) !!}, backgroundColor: 'rgba(108, 117, 125, 0.7)', borderWidth: 1 },
                                        { label: 'Vigente', data: {!! json_encode($grafica->vigente ?? []) !!}, backgroundColor: 'rgba(54, 162, 235, 0.7)', borderWidth: 1 },
                                        { label: 'Pagado', data: {!! json_encode($grafica->pagado ?? []) !!}, backgroundColor: 'rgba(25, 135, 84, 0.7)', borderWidth: 1 },
                                        // CAMBIO DE COLOR DEL SALDO A AZUL (#0d6efd)
                                        { label: 'Saldo', data: {!! json_encode($grafica->diferencia ?? []) !!}, backgroundColor: 'rgba(13, 110, 253, 0.8)', borderWidth: 1 }
                                    ]
                                },
                                options: {
                                    responsive: true, maintainAspectRatio: false,
                                    scales: { 
                                        y: { 
                                            beginAtZero: true,
                                            ticks: {
                                                callback: function(value) {
                                                    if (value >= 1000000) return '$' + (value / 1000000).toFixed(1) + 'M';
                                                    if (value >= 1000) return '$' + (value / 1000).toFixed(1) + 'k';
                                                    return '$' + value;
                                                }
                                            }
                                        } 
                                    },
                                    plugins: {
                                        tooltip: {
                                            callbacks: {
                                                label: function(context) {
                                                    let label = context.dataset.label || '';
                                                    if (label) { label += ': '; }
                                                    if (context.parsed.y !== null) {
                                                        label += new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(context.parsed.y);
                                                    }
                                                    return label;
                                                }
                                            }
                                        }
                                    }
                                }
                            });
                        }

                        // 2. INICIALIZAR GRÁFICA DE PASTEL (Doughnut)
                        const ctxPastel = document.getElementById('grafica_pastel_{{ $reporte->id }}');
                        if (ctxPastel) {
                            new Chart(ctxPastel.getContext('2d'), {
                                type: 'doughnut', 
                                data: {
                                    labels: {!! json_encode($grafica->labels ?? []) !!}, 
                                    datasets: [{
                                        label: 'Total Pagado ($)',
                                        data: {!! json_encode($grafica->pagado ?? []) !!}, 
                                        backgroundColor: paletaColores,
                                        borderWidth: 1
                                    }]
                                },
                                options: {
                                    responsive: true,
                                    maintainAspectRatio: false,
                                    plugins: {
                                        legend: { position: 'right' }, 
                                        tooltip: {
                                            callbacks: {
                                                label: function(context) {
                                                    let valor = context.parsed;
                                                    return ' Pagado: ' + new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(valor);
                                                }
                                            }
                                        }
                                    }
                                }
                            });
                        }
                    });
                </script>
            @endforeach
        </div>
    @endif
</div>
@endsection